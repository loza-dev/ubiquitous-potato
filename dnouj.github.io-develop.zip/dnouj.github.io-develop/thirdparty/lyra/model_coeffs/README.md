TFLITE MODELS SOURCED FROM GOOGLE ON GITHUB

google/lyra is licensed under the
Apache License 2.0
https://github.com/google/lyra
https://github.com/google/lyra/tree/f079e8c4dd1c61c87de1852178976ee3bdf15561/model_coeffs