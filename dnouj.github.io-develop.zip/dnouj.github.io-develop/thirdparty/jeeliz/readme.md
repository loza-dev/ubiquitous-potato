 Many of the files found in this folder are obtained from Jeeliz
 
 jeelize/jeelizFaceFilter
 Apache-2.0 License
 
 https://github.com/jeeliz/jeelizFaceFilter/blob/master/LICENSE